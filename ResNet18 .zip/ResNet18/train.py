
import argparse
import os
import random

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, random_split
from torchvision import transforms

from data.voc_dataset import VOCDataset

# 导入三个模型
from models.resnet18 import build_model as build_resnet18
from models.se_resnet18 import build_model as build_se_resnet18
from models.se_gelu_resnet18 import build_model as build_se_gelu_resnet18

from utils.engine import run_epoch
from utils.metrics import multilabel_metrics


def seed_all(seed):
    """固定随机种子，保证实验可复现"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def main():

    parser = argparse.ArgumentParser(
        description="ResNet18系列模型在VOC2007上的多标签分类训练"
    )

    # 数据集路径
    parser.add_argument(
        "--data",
        type=str,
        default="train/VOCdevkit/VOC2007"
    )

    # 模型选择
    parser.add_argument(
        "--model",
        type=str,
        choices=[
            "resnet18",
            "se_resnet18",
            "se_gelu_resnet18"
        ],
        default="se_gelu_resnet18"
    )

    # 训练参数
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--image-size", type=int, default=224)

    # 是否关闭预训练权重
    parser.add_argument(
        "--no-pretrained",
        action="store_true"
    )

    # 模型保存目录
    parser.add_argument(
        "--output",
        type=str,
        default="checkpoints"
    )

    args = parser.parse_args()

    # 固定随机种子
    seed_all(args.seed)

    # 自动选择设备
    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    print(f"模型: {args.model} | 设备: {device}")
    print(
        f"训练轮数: {args.epochs} | "
        f"Batch Size: {args.batch_size} | "
        f"学习率: {args.lr}"
    )

    # ==============================
    # 1. 数据预处理
    # ==============================

    train_tf = transforms.Compose([
        transforms.Resize(
            (args.image_size, args.image_size)
        ),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(
            brightness=0.15,
            contrast=0.15,
            saturation=0.15,
            hue=0.05
        ),
        transforms.ToTensor(),
        transforms.Normalize(
            [0.485, 0.456, 0.406],
            [0.229, 0.224, 0.225]
        )
    ])

    eval_tf = transforms.Compose([
        transforms.Resize(
            (args.image_size, args.image_size)
        ),
        transforms.ToTensor(),
        transforms.Normalize(
            [0.485, 0.456, 0.406],
            [0.229, 0.224, 0.225]
        )
    ])

    # ==============================
    # 2. 加载数据集
    # ==============================

    all_ds = VOCDataset(
        args.data,
        split="trainval",
        transform=None
    )

    # 划分训练集和验证集
    n_val = max(1, int(len(all_ds) * 0.1))
    n_train = len(all_ds) - n_val

    generator = torch.Generator().manual_seed(args.seed)

    train_subset, val_subset = random_split(
        range(len(all_ds)),
        [n_train, n_val],
        generator=generator
    )

    train_ids = [
        all_ds.items[i][3]
        for i in train_subset.indices
    ]

    val_ids = [
        all_ds.items[i][3]
        for i in val_subset.indices
    ]

    train_ds = VOCDataset(
        args.data,
        split="trainval",
        transform=train_tf,
        ids=train_ids
    )

    val_ds = VOCDataset(
        args.data,
        split="trainval",
        transform=eval_tf,
        ids=val_ids
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers,
        pin_memory=(device.type == "cuda")
    )

    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=(device.type == "cuda")
    )

    print(
        f"训练集: {len(train_ds)} | "
        f"验证集: {len(val_ds)}"
    )

    # ==============================
    # 3. 创建模型
    # ==============================

    pretrained = not args.no_pretrained

    if args.model == "resnet18":

        model = build_resnet18(
            pretrained=pretrained
        )

    elif args.model == "se_resnet18":

        model = build_se_resnet18(
            pretrained=pretrained
        )

    elif args.model == "se_gelu_resnet18":

        model = build_se_gelu_resnet18(
            pretrained=pretrained,
            num_classes=20
        )

    model = model.to(device)

    # ==============================
    # 4. 损失函数和优化器
    # ==============================

    criterion = nn.BCEWithLogitsLoss(
        reduction="none"
    )

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=1e-4
    )

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=args.epochs
    )

    os.makedirs(args.output, exist_ok=True)

    best_map = -1.0

    # ==============================
    # 5. 开始训练
    # ==============================

    for epoch in range(1, args.epochs + 1):

        # 训练阶段
        train_loss, _, _, _ = run_epoch(
            model,
            train_loader,
            criterion,
            device,
            optimizer
        )

        # 验证阶段
        val_loss, y_true, y_score, mask = run_epoch(
            model,
            val_loader,
            criterion,
            device
        )

        # 计算评价指标
        metrics = multilabel_metrics(
            y_true,
            y_score,
            mask
        )

        # 更新学习率
        scheduler.step()

        # 紧凑输出，不额外插入空行
        print(
            f"Epoch [{epoch:02d}/{args.epochs}] "
            f"train_loss: {train_loss:.4f} | "
            f"val_loss: {val_loss:.4f} | "
            f"mAP: {metrics['mAP']:.4f} | "
            f"P: {metrics['precision']:.4f} | "
            f"R: {metrics['recall']:.4f} | "
            f"F1: {metrics['f1']:.4f}",
            flush=True
        )

        # ==============================
        # 6. 保存模型
        # ==============================

        state = {
            "model": model.state_dict(),
            "model_name": args.model,
            "epoch": epoch,
            "val_metrics": metrics,
            "args": vars(args),
            "classes": list(
                __import__(
                    "data.voc_dataset",
                    fromlist=["VOC_CLASSES"]
                ).VOC_CLASSES
            )
        }

        # 保存最后一轮模型
        last_path = os.path.join(
            args.output,
            f"{args.model}_last.pth"
        )

        torch.save(state, last_path)

        # 保存最佳模型，不输出保存提示
        if metrics["mAP"] > best_map:

            best_map = metrics["mAP"]

            best_path = os.path.join(
                args.output,
                f"{args.model}_best.pth"
            )

            torch.save(state, best_path)

    # ==============================
    # 7. 训练结束
    # ==============================

    print(
        f"\n训练完成！模型: {args.model} | "
        f"最佳验证集 mAP: {best_map:.4f}"
    )


if __name__ == "__main__":
    main()
