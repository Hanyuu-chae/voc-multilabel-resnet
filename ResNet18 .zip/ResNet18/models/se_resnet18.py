
from torch import nn
from torchvision.models import resnet18

try:
    from torchvision.models import ResNet18_Weights
except ImportError:
    ResNet18_Weights = None


class SEBlock(nn.Module):
    def __init__(self, channels, reduction=16):
        super().__init__()

        hidden_channels = max(channels // reduction, 1)

        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, hidden_channels, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_channels, channels, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        batch_size, channels, _, _ = x.size()

        weights = self.pool(x).view(batch_size, channels)
        weights = self.fc(weights).view(
            batch_size, channels, 1, 1
        )

        return x * weights


class SEBasicBlock(nn.Module):
    expansion = 1

    def __init__(self, original_block, reduction=16):
        super().__init__()

        self.conv1 = original_block.conv1
        self.bn1 = original_block.bn1
        self.relu = original_block.relu
        self.conv2 = original_block.conv2
        self.bn2 = original_block.bn2
        self.downsample = original_block.downsample
        self.stride = original_block.stride

        self.se = SEBlock(
            self.bn2.num_features,
            reduction
        )

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        out = self.se(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


def build_model(pretrained=True, num_classes=20):

    if ResNet18_Weights is not None:
        weights = ResNet18_Weights.DEFAULT if pretrained else None
        model = resnet18(weights=weights)
    else:
        model = resnet18(pretrained=pretrained)

    for layer_name in ["layer1", "layer2", "layer3", "layer4"]:
        layer = getattr(model, layer_name)

        for i in range(len(layer)):
            layer[i] = SEBasicBlock(
                layer[i],
                reduction=16
            )

    model.fc = nn.Linear(
        model.fc.in_features,
        num_classes
    )

    return model
