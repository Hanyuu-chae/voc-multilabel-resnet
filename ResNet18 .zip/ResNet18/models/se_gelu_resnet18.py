
import torch
from torch import nn
from torchvision import models


class SEBlock(nn.Module):
    """Squeeze-and-Excitation 通道注意力模块。"""

    def __init__(self, channels, reduction=16):
        super().__init__()

        hidden_channels = max(channels // reduction, 1)

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, hidden_channels, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_channels, channels, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        batch_size, channels, _, _ = x.size()

        weight = self.avg_pool(x).view(batch_size, channels)
        weight = self.fc(weight).view(batch_size, channels, 1, 1)

        return x * weight


class SEGELUBasicBlock(nn.Module):
    """在 ResNet BasicBlock 中加入 SE 注意力，并使用 GELU 激活。"""

    expansion = 1

    def __init__(self, original_block):
        super().__init__()

        # 直接复用原始 ResNet-18 的卷积层和 BN 层
        self.conv1 = original_block.conv1
        self.bn1 = original_block.bn1
        self.conv2 = original_block.conv2
        self.bn2 = original_block.bn2

        self.downsample = original_block.downsample
        self.stride = original_block.stride

        channels = self.bn2.num_features
        self.se = SEBlock(channels)

        self.gelu = nn.GELU()

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.gelu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        # SE 通道注意力
        out = self.se(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.gelu(out)

        return out


def build_model(pretrained=True, num_classes=20):
    """
    构建 SE-GELU-ResNet18。

    pretrained=True：加载 ImageNet 预训练权重。
    num_classes=20：适配 VOC2007 的 20 类多标签分类。
    """

    # 兼容不同版本的 torchvision
    try:
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
    except (AttributeError, TypeError):
        model = models.resnet18(pretrained=pretrained)

    # 将 ResNet-18 的 BasicBlock 替换为 SE + GELU 版本
    for layer_name in ["layer1", "layer2", "layer3", "layer4"]:
        layer = getattr(model, layer_name)

        for i in range(len(layer)):
            layer[i] = SEGELUBasicBlock(layer[i])

    # 将网络最前面的 ReLU 也替换为 GELU
    model.relu = nn.GELU()

    # 替换分类头：输出 VOC2007 的 20 个类别
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)

    return model
