import argparse, torch, json
from torch.utils.data import DataLoader
from torchvision import transforms
from data.voc_dataset import VOCDataset
from models.resnet18 import build_model
from utils.engine import run_epoch
from utils.metrics import multilabel_metrics

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data',default='VOCdevkit/VOC2007'); p.add_argument('--weights',required=True)
    p.add_argument('--batch-size',type=int,default=32); p.add_argument('--workers',type=int,default=4)
    a=p.parse_args(); device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ckpt=torch.load(a.weights,map_location=device); name=ckpt.get('model_name','resnet18')
    model=build_model(name,pretrained=False).to(device); model.load_state_dict(ckpt['model']); model.eval()
    tf=transforms.Compose([transforms.Resize((224,224)),transforms.ToTensor(),
        transforms.Normalize([.485,.456,.406],[.229,.224,.225])])
    ds=VOCDataset(a.data,split='test',transform=tf)
    loader=DataLoader(ds,batch_size=a.batch_size,shuffle=False,num_workers=a.workers)
    loss,y,s,m=run_epoch(model,loader,torch.nn.BCEWithLogitsLoss(reduction='none'),device)
    result=multilabel_metrics(y,s,m); result['test_loss']=loss
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
