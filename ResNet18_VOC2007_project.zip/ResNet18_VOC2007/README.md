# ResNet-18 / SE-ResNet-18 on VOC2007

本目录是从原 YOLOv4-Tiny 项目中独立迁移出来的**图像级多标签分类**实验，不会覆盖原 YOLO 工程。模型对每张图片输出 VOC 20 类的存在概率；它不预测边界框，因此不能替代 YOLO 目标检测。

## 1. 与原 YOLO 项目的关系

原工程采用 `YoloBody`、YOLO 检测头、锚框和 `YOLOLoss`，训练标签是每个目标的边界框及类别。本项目保留 VOC2007 数据集和类别定义的使用方式，但改成 ResNet-18 分类头、20 维多标签输出、`BCEWithLogitsLoss`，评价采用图片级多标签指标。原项目里的 Coordinate Attention 不直接搬进本项目；改进模型采用 SE 注意力，以便做清晰的基线对照。

## 2. 数据集准备

你上传的压缩包内只有 `VOCdevkit/VOC2007` 的目录占位说明，没有实际 JPEG 图片和 XML 标注。请将完整 VOC2007 数据放到：

```text
ResNet18_VOC2007/
└── VOCdevkit/
    └── VOC2007/
        ├── Annotations/       # *.xml
        ├── JPEGImages/        # *.jpg
        └── ImageSets/
            └── Main/
                ├── trainval.txt
                └── test.txt
```

`trainval.txt` 和 `test.txt` 应使用 VOC 官方划分。程序将 `trainval` 按固定随机种子切成 90% 训练、10% 验证；`test` 只用于最终测试。不要用 test 集挑模型或调超参数。

类别采用 VOC 2007 的标准 20 类，名称顺序见 `data/voc_dataset.py`。数据读取直接解析 XML，不需要 YOLO 的 `2007_train.txt` / `2007_val.txt`。

### difficult 标注处理

普通目标会作为正标签；没有出现的类别作为负标签。若某类别在一张图中只出现 `difficult=1` 的目标，该类别对应的 loss/指标 mask 设为 0，避免把难例误标成负样本。若同一类别同时有普通目标和 difficult 目标，仍视为正样本。

## 3. 环境安装

建议 Python 3.9–3.11，并按本机 CUDA 情况安装匹配版本的 PyTorch / torchvision。然后：

```bash
pip install -r requirements.txt
```

首次使用默认 `--pretrained` 会由 torchvision 下载 ImageNet 预训练权重；无网络环境可加 `--no-pretrained`，但从零训练通常效果较弱。

## 4. 训练

在项目根目录执行：

```bash
python train.py --data VOCdevkit/VOC2007 --model resnet18 --epochs 40 --batch-size 32
python train.py --data VOCdevkit/VOC2007 --model se_resnet18 --epochs 40 --batch-size 32
```

显存不足时调小 `--batch-size`（例如 16 或 8），CPU 环境建议 `--workers 0`。权重保存在 `checkpoints/`，包括 `*_best.pth` 和 `*_last.pth`。

## 5. 最终测试

```bash
python evaluate.py --data VOCdevkit/VOC2007 --weights checkpoints/resnet18_best.pth
python evaluate.py --data VOCdevkit/VOC2007 --weights checkpoints/se_resnet18_best.pth
```

输出包含 VOC 2007 11-point AP 的 mAP、Precision、Recall、F1 和测试损失。Precision/Recall/F1 使用 0.5 概率阈值；mAP 按每类排序分数计算。difficult-only 标签在相应类别上忽略。

## 6. 参数量与计算量

```bash
python compare_models.py --image-size 224
```

该脚本会打印参数量；安装 `thop` 后还会估算 FLOPs。两种模型必须使用相同输入尺寸和设备/测量方式进行公平比较。注意不同 FLOPs 工具对 MACs/FLOPs 的定义可能不同，报告中应注明所用工具。

## 7. 实验建议与报告注意事项

- 对比组：ResNet-18（基线）与 SE-ResNet-18（加入通道注意力）。
- 固定数据划分、随机种子、输入尺寸、训练轮数、优化器和学习率，避免对比不公平。
- 训练结束后记录最佳验证 mAP、最终测试 mAP、Precision、Recall、F1、参数量、FLOPs、训练耗时。
- 不能把分类 mAP 与原 YOLO 的检测 mAP 当成同一任务的指标；二者含义不同。
- 当前压缩包没有数据文件、预训练权重或实验日志，因此本仓库不会虚构训练曲线或准确率。需在本地补齐 VOC 数据并实际训练后填写报告结果。
