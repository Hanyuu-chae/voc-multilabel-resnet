import torch
from tqdm import tqdm

def run_epoch(model,loader,criterion,device,optimizer=None):
    training=optimizer is not None
    model.train(training); total=0.; count=0
    all_y=[]; all_s=[]; all_m=[]
    context=torch.enable_grad if training else torch.no_grad
    with context():
        for images,labels,masks,_ in tqdm(loader,leave=False):
            images=images.to(device); labels=labels.to(device); masks=masks.to(device)
            logits=model(images)
            element=criterion(logits,labels)
            loss=(element*masks).sum()/masks.sum().clamp_min(1.)
            if training:
                optimizer.zero_grad(set_to_none=True); loss.backward()
                optimizer.step()
            n=images.size(0); total+=loss.item()*n; count+=n
            all_y.append(labels.cpu()); all_s.append(torch.sigmoid(logits).detach().cpu()); all_m.append(masks.cpu())
    return total/max(count,1),torch.cat(all_y).numpy(),torch.cat(all_s).numpy(),torch.cat(all_m).numpy()
