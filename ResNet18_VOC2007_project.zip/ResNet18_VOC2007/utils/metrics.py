import numpy as np
from sklearn.metrics import average_precision_score, precision_recall_fscore_support

def voc07_ap(rec,prec):
    """VOC 2007 11-point interpolated AP."""
    ap=0.
    for t in np.arange(0.,1.1,.1):
        p=prec[rec>=t]
        ap += (p.max() if p.size else 0.)/11.
    return float(ap)

def multilabel_metrics(targets,scores,masks=None,threshold=.5):
    targets=np.asarray(targets); scores=np.asarray(scores)
    masks=np.ones_like(targets,dtype=bool) if masks is None else np.asarray(masks).astype(bool)
    aps=[]; valid=[]
    for c in range(targets.shape[1]):
        keep=masks[:,c]
        y=targets[keep,c]; s=scores[keep,c]
        if y.size and np.any(y==1):
            order=np.argsort(-s); y=y[order]
            tp=np.cumsum(y==1); fp=np.cumsum(y==0)
            rec=tp/max(int((y==1).sum()),1); prec=tp/np.maximum(tp+fp,1)
            aps.append(voc07_ap(rec,prec)); valid.append(c)
    pred=(scores>=threshold).astype(int)
    # 聚合时只统计有效标签位置
    y=targets[masks].astype(int); p=pred[masks]
    precision,recall,f1,_=precision_recall_fscore_support(y,p,average='binary',zero_division=0)
    return {'mAP':float(np.mean(aps)) if aps else 0.,'AP_per_class':aps,'valid_classes':valid,
            'precision':float(precision),'recall':float(recall),'f1':float(f1)}
