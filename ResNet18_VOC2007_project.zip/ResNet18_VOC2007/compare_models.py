import argparse, torch
from models.resnet18 import build_model

def main():
    p=argparse.ArgumentParser(); p.add_argument('--image-size',type=int,default=224); a=p.parse_args()
    device='cuda' if torch.cuda.is_available() else 'cpu'
    for name in ('resnet18','se_resnet18'):
        model=build_model(name,pretrained=False).to(device).eval()
        params=sum(x.numel() for x in model.parameters())
        x=torch.randn(1,3,a.image_size,a.image_size,device=device)
        try:
            from thop import profile
            flops,_=profile(model,inputs=(x,),verbose=False); flops_text=f'{flops/1e9:.3f} GFLOPs'
        except ImportError: flops_text='未安装 thop（pip install thop）'
        with torch.no_grad(): y=model(x)
        print(f'{name:12s} params={params:,} ({params/1e6:.3f} M), FLOPs={flops_text}, output={tuple(y.shape)}')
if __name__=='__main__': main()
