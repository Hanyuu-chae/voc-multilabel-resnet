import torch
from torch import nn
from torchvision.models import resnet18, ResNet18_Weights
from torchvision.models.resnet import BasicBlock, ResNet

class SE(nn.Module):
    def __init__(self, channels, reduction=16):
        super().__init__()
        hidden=max(channels//reduction, 8)
        self.pool=nn.AdaptiveAvgPool2d(1)
        self.fc=nn.Sequential(nn.Linear(channels,hidden,bias=False),nn.ReLU(inplace=True),
                              nn.Linear(hidden,channels,bias=False),nn.Sigmoid())
    def forward(self,x):
        b,c,_,_=x.shape
        return x*self.fc(self.pool(x).view(b,c)).view(b,c,1,1)

class SEBasicBlock(BasicBlock):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.se=SE(self.conv2.out_channels)
    def forward(self,x):
        identity=x
        out=self.conv1(x); out=self.bn1(out); out=self.relu(out)
        out=self.conv2(out); out=self.bn2(out); out=self.se(out)
        if self.downsample is not None: identity=self.downsample(x)
        out=out+identity
        return self.relu(out)

class SEResNet18(ResNet):
    def __init__(self,num_classes=20):
        super().__init__(SEBasicBlock,[2,2,2,2],num_classes=num_classes)
    def forward(self,x):
        return super().forward(x)

def build_model(name='resnet18',num_classes=20,pretrained=True):
    if name=='resnet18':
        weights=ResNet18_Weights.DEFAULT if pretrained else None
        model=resnet18(weights=weights)
        model.fc=nn.Linear(model.fc.in_features,num_classes)
        return model
    if name=='se_resnet18':
        model=SEResNet18(num_classes)
        if pretrained:
            base=resnet18(weights=ResNet18_Weights.DEFAULT)
            # 载入与标准ResNet18同名且同形状的卷积/BN参数；SE和分类头保持新初始化
            own=model.state_dict()
            compatible={k:v for k,v in base.state_dict().items()
                        if k in own and own[k].shape==v.shape and k!='fc.weight' and k!='fc.bias'}
            model.load_state_dict(compatible,strict=False)
        return model
    raise ValueError(f'Unknown model: {name}')
