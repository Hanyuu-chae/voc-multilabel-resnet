import argparse, os, random, numpy as np, torch
from torch import nn
from torch.utils.data import DataLoader, random_split, Subset
from torchvision import transforms
from data.voc_dataset import VOCDataset
from models.resnet18 import build_model
from utils.engine import run_epoch
from utils.metrics import multilabel_metrics

def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data',default='VOCdevkit/VOC2007')
    p.add_argument('--model',choices=['resnet18','se_resnet18'],default='resnet18')
    p.add_argument('--epochs',type=int,default=40); p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--lr',type=float,default=1e-4); p.add_argument('--workers',type=int,default=4)
    p.add_argument('--seed',type=int,default=42); p.add_argument('--image-size',type=int,default=224)
    p.add_argument('--no-pretrained',action='store_true'); p.add_argument('--output',default='checkpoints')
    args=p.parse_args(); seed_all(args.seed)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    train_tf=transforms.Compose([transforms.Resize((args.image_size,args.image_size)),
        transforms.RandomHorizontalFlip(),transforms.ColorJitter(.15,.15,.15,.05),
        transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])])
    eval_tf=transforms.Compose([transforms.Resize((args.image_size,args.image_size)),
        transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])])
    # 依据VOC官方trainval划分做固定随机训练/验证拆分；test仅留作最终测试。
    all_ds=VOCDataset(args.data,split='trainval',transform=None)
    n_val=max(1,int(len(all_ds)*.1)); n_train=len(all_ds)-n_val
    g=torch.Generator().manual_seed(args.seed)
    train_idx,val_idx=random_split(range(len(all_ds)),[n_train,n_val],generator=g)
    train_ds=VOCDataset(args.data,split='trainval',transform=train_tf,ids=[all_ds.items[i][3] for i in train_idx.indices])
    val_ds=VOCDataset(args.data,split='trainval',transform=eval_tf,ids=[all_ds.items[i][3] for i in val_idx.indices])
    train_loader=DataLoader(train_ds,batch_size=args.batch_size,shuffle=True,num_workers=args.workers,pin_memory=device.type=='cuda')
    val_loader=DataLoader(val_ds,batch_size=args.batch_size,shuffle=False,num_workers=args.workers,pin_memory=device.type=='cuda')
    model=build_model(args.model,pretrained=not args.no_pretrained).to(device)
    criterion=nn.BCEWithLogitsLoss(reduction='none')
    optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=1e-4)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=args.epochs)
    os.makedirs(args.output,exist_ok=True); best=-1
    for epoch in range(1,args.epochs+1):
        tr_loss,_,_,_=run_epoch(model,train_loader,criterion,device,optimizer)
        va_loss,y,s,m=run_epoch(model,val_loader,criterion,device)
        metrics=multilabel_metrics(y,s,m)
        scheduler.step()
        print(f'Epoch {epoch:03d}/{args.epochs} train_loss={tr_loss:.4f} val_loss={va_loss:.4f} '
              f'mAP07={metrics["mAP"]:.4f} P={metrics["precision"]:.4f} R={metrics["recall"]:.4f} F1={metrics["f1"]:.4f}')
        state={'model':model.state_dict(),'model_name':args.model,'epoch':epoch,'val_metrics':metrics,
               'args':vars(args),'classes':list(__import__('data.voc_dataset',fromlist=['VOC_CLASSES']).VOC_CLASSES)}
        torch.save(state,os.path.join(args.output,f'{args.model}_last.pth'))
        if metrics['mAP']>best:
            best=metrics['mAP']; torch.save(state,os.path.join(args.output,f'{args.model}_best.pth'))
    print('训练结束。最佳验证集 VOC07 mAP:',best)
if __name__=='__main__': main()
