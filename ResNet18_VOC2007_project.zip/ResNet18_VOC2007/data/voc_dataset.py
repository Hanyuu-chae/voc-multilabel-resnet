import os, xml.etree.ElementTree as ET
from PIL import Image
import torch
from torch.utils.data import Dataset

VOC_CLASSES=('aeroplane','bicycle','bird','boat','bottle','bus','car','cat','chair','cow',
             'diningtable','dog','horse','motorbike','person','pottedplant','sheep','sofa','train','tvmonitor')
CLASS_TO_IDX={name:i for i,name in enumerate(VOC_CLASSES)}

class VOCDataset(Dataset):
    """VOC2007 多标签分类数据集；difficult-only 类别通过 mask 排除损失和评估。"""
    def __init__(self,root,split='train',transform=None,ids=None):
        self.root=root; self.transform=transform
        ann_dir=os.path.join(root,'Annotations'); img_dir=os.path.join(root,'JPEGImages')
        if ids is None:
            split_file=os.path.join(root,'ImageSets','Main',split+'.txt')
            if not os.path.isfile(split_file):
                raise FileNotFoundError(f'找不到划分文件: {split_file}')
            with open(split_file,encoding='utf-8') as f: ids=[x.strip() for x in f if x.strip()]
        self.items=[]
        missing=[]
        for image_id in ids:
            xml=os.path.join(ann_dir,image_id+'.xml')
            image=None
            for ext in ('.jpg','.jpeg','.png'):
                candidate=os.path.join(img_dir,image_id+ext)
                if os.path.isfile(candidate): image=candidate; break
            if not os.path.isfile(xml) or image is None:
                missing.append(image_id); continue
            labels=torch.zeros(len(VOC_CLASSES),dtype=torch.float32)
            mask=torch.ones(len(VOC_CLASSES),dtype=torch.float32)
            root=ET.parse(xml).getroot()
            normal=set(); difficult=set()
            for obj in root.findall('object'):
                name=obj.findtext('name','').strip()
                if name not in CLASS_TO_IDX: continue
                idx=CLASS_TO_IDX[name]
                if int(obj.findtext('difficult','0') or 0)==1: difficult.add(idx)
                else: normal.add(idx)
            for idx in normal: labels[idx]=1.
            for idx in difficult-normal: mask[idx]=0.
            self.items.append((image,labels,mask,image_id))
        if not self.items:
            raise RuntimeError(f'{root} 下未读取到有效样本，请检查JPEGImages与Annotations。')
        if missing: print(f'[提示] 跳过 {len(missing)} 个缺失图片/XML的样本。')
    def __len__(self): return len(self.items)
    def __getitem__(self,index):
        path,label,mask,image_id=self.items[index]
        image=Image.open(path).convert('RGB')
        if self.transform: image=self.transform(image)
        return image,label,mask,image_id
